# PHP Viope Course
Exercises of introduction to PHP programming via Viope online course, covering the basics of the PHP language. This course was part of my first year studies (optional studies) at Metropolia UAS, Bachelor of Engineering.

The course material and exercises are in Finnish.

## Course content:
+ General information about web strandards and PHP
+ Forms and PHP
+ Variables
+ Control Structures
+ Arrays
+ Expressions
+ Operators
+ Functions
+ Files
+ Processing of permanent information
+ Security
